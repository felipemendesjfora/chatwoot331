class ApplicationCable::Connection < ActionCable::Connection::Base
end
