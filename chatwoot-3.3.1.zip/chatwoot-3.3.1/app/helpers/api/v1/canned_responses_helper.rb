module Api::V1::CannedResponsesHelper
end
