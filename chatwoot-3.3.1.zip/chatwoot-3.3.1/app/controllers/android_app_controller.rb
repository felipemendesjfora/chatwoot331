class AndroidAppController < ApplicationController
  def assetlinks
    render layout: false
  end
end
